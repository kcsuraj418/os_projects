/**
 * Tony Givargis
 * Copyright (C), 2023
 * University of California, Irvine
 *
 * CS 238P - Operating Systems
 * jitc.c
 */

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <dlfcn.h>
#include "system.h"
#include "jitc.h"

/**
 * Needs:
 *   fork()
 *   execv()
 *   waitpid()
 *   WIFEXITED()
 *   WEXITSTATUS()
 *   dlopen()
 *   dlclose()
 *   dlsym()
 */

/* research the above Needed API and design accordingly */
struct jitc{
	void * handle;
};

int jitc_compile(const char *input, const char *output){
    long pid;
    pid = fork();
    if (0==pid){
        char * arg[8];
        arg[0] = "gcc";
        arg[1] = "-O3";
        arg[2] = "-fpic";
        arg[3] = "-shared";
        arg[4] = "-o";
        arg[5] = (char *) output;
        arg[6] = (char *) input;
	arg[7] = NULL;
        execv("/usr/bin/gcc",arg);
        exit(0);
    }
    else if(pid>0){
        /* Parent Process - wait for execution of child process and finish*/
        int status;
        waitpid(pid, &status, 0);
        if ( WIFEXITED(status) ){
        int exit_status = WEXITSTATUS(status);        
        printf("Exit status of the child was %d\n", exit_status);}
        return 0;
    }
    else{
        TRACE("\nfork creation failed!!!\n");
        return -1;
    }
}

struct jitc *jitc_open(const char *pathname){
	struct jitc *handle = (struct jitc *)malloc(sizeof(struct jitc));
	handle->handle = dlopen(pathname,RTLD_LAZY| RTLD_LOCAL);
	if (!handle){
		TRACE("HANDLE is NULL");
	}
	return handle;
	
}

void jitc_close(struct jitc *jitc){
	dlclose(jitc->handle);
	free(jitc);
}

long jitc_lookup(struct jitc *jitc, const char *symbol){
	void *address= dlsym(jitc->handle,symbol);
	if (address==NULL){
		TRACE("Address is not present");
	}
	return (long) address;
	
}


