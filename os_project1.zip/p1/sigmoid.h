#ifndef DEF_SIGMOID
#define DEF_SIGMOID

#define EULER_NUMBER 2.71828

double sigmoid(double n);

#endif
